
export const SYSTEM_SHORT_NAME = "his" //Use for requssting different apps
export const SYSTEM_LOCAL_NAME = "医生排班系统" 
<<<<<<< HEAD
export const BUILD_TIIME="Fri Mar 22 12:20:12 CST 2019"
=======
export const BUILD_TIIME="Tue Mar 12 13:30:09 CST 2019"
>>>>>>> f0fec7af5ee3d5cf047fe422adb18787dcd4aa89
export const MEDIA_UPLOAD_URL="https://www.doublechaintech.com/mss/upload.html"
export const MEDIA_PREFIX="https://www.doublechaintech.com/mss/"

const SystemConfig={SYSTEM_SHORT_NAME,BUILD_TIIME,MEDIA_UPLOAD_URL,SYSTEM_LOCAL_NAME,MEDIA_PREFIX};

export default SystemConfig











