package com.doublechaintech.his;
public class EntityNotFoundException extends HisException {
	private static final long serialVersionUID = 1L;
	public EntityNotFoundException(String string) {
		super(string);
	}

}


