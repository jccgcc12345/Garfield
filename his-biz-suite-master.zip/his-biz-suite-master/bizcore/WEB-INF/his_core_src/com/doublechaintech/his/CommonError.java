package com.doublechaintech.his;

public class CommonError extends BaseEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

