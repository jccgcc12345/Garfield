package com.doublechaintech.his;

public class AggrResult extends Object {
	
	public BaseEntity getKey() {
		return key;
	}

	public void setKey(BaseEntity key) {
		this.key = key;
	}

	public int getCount() {
		return count;
	}

	public void setValue(int value) {
		this.count = value;
	}

	private BaseEntity key;
	
	private int count;
	
	
	
}




















