package com.skynet.infrastructure;

public class InfraBaseService {

	public InfraBaseService() {
		// TODO Auto-generated constructor stub
	}

}
