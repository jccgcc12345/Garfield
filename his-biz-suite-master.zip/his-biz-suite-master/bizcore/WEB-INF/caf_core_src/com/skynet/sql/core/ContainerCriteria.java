package com.skynet.sql.core;

public interface ContainerCriteria extends Container, Criteria {
}
