package com.skynet.sql.core;

public interface Container {
    Container append(Criteria pCriteria);
}
