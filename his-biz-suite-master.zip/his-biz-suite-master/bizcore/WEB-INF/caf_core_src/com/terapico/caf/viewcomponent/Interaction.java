package com.terapico.caf.viewcomponent;

public class Interaction {
    // TODO: 待定。互动的部分需要更多的工作。
    // 目前设想是两大类互动：一类是简单的show/hide某个元素，一类是触发后台刷新局/全部页面
}
