package com.terapico.caf;


public class InvocationBase {

}
