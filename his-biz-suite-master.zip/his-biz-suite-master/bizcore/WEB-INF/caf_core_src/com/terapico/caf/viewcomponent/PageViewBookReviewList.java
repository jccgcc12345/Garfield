package com.terapico.caf.viewcomponent;

/**
 * 标明此页是“动态”
 * @author clariones
 *
 */
public class PageViewBookReviewList extends PageViewComponent {

    public PageViewBookReviewList() {
        super();
    }

    public PageViewBookReviewList(String title) {
        super(title);
    }

}
