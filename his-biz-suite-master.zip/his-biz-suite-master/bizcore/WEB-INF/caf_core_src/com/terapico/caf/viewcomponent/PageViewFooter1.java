package com.terapico.caf.viewcomponent;

/**
 * 标明此页是‘历史足迹’
 * @author clariones
 *
 */
public class PageViewFooter1 extends PageViewComponent {

    public PageViewFooter1() {
        super();
    }

    public PageViewFooter1(String title) {
        super(title);
    }

}
