package com.terapico.caf.viewcomponent;

/**
 * 标明此页是‘历史足迹’
 * @author clariones
 *
 */
public class PageViewFootPrint extends PageViewComponent {

    public PageViewFootPrint() {
        super();
    }

    public PageViewFootPrint(String title) {
        super(title);
    }

}
