package com.terapico.caf;

public class LogEntry {

}
