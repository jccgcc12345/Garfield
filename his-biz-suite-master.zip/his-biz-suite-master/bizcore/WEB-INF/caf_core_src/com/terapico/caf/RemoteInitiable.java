package com.terapico.caf;

public interface RemoteInitiable {
	
}
