package com.terapico.caf;
import java.util.List;

import  com.terapico.caf.baseelement.*;
public interface CookieProvider {
	public List<Cookie> getCookies();
}
