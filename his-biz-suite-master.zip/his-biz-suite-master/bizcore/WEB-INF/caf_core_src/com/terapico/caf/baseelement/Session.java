package com.terapico.caf.baseelement;

public class Session extends Cookie {
	boolean httpOnly = true;
	public Session() {
		// TODO Auto-generated constructor stub
	}
	public boolean isHttpOnly() {
		return httpOnly;
	}
	
	
	
}
