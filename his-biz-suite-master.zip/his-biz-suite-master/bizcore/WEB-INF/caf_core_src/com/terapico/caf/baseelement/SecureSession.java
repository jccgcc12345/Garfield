package com.terapico.caf.baseelement;

public class SecureSession extends Session {
	boolean secure = true;
	public SecureSession() {
		
	}
	public boolean isSecure() {
		return secure;
	}

	

}
