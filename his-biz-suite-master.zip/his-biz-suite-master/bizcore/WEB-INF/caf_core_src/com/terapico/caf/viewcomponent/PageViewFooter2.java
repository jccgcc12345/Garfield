package com.terapico.caf.viewcomponent;

/**
 * 标明此页是‘历史足迹’
 * @author clariones
 *
 */
public class PageViewFooter2 extends PageViewComponent {

    public PageViewFooter2() {
        super();
    }

    public PageViewFooter2(String title) {
        super(title);
    }

}
