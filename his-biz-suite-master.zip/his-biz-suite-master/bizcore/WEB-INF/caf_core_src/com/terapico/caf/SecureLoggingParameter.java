package com.terapico.caf;

public interface SecureLoggingParameter {
	public String toLoggingString() ;
	public Object getValue() ;
}
