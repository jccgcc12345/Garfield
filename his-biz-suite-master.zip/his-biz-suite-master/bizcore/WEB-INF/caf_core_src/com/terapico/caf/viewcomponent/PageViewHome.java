package com.terapico.caf.viewcomponent;

/**
 * 标明此页是首页
 * @author clariones
 *
 */
public class PageViewHome extends PageViewComponent {

    public PageViewHome() {
        super();
    }

    public PageViewHome(String title) {
        super(title);
    }

}
