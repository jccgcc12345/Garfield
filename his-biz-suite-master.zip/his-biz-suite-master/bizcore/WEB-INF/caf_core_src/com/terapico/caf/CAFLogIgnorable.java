package com.terapico.caf;

public interface CAFLogIgnorable {

}
