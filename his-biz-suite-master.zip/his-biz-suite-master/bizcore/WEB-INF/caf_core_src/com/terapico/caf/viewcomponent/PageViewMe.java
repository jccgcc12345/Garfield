package com.terapico.caf.viewcomponent;

/**
 * 标明此页是‘我的’
 * @author clariones
 *
 */
public class PageViewMe extends PageViewComponent {

    public PageViewMe() {
        super();
    }

    public PageViewMe(String title) {
        super(title);
    }

}
